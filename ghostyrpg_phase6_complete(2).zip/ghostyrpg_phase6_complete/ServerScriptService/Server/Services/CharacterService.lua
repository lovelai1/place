--!strict
-- Bridges server player-data with the Roblox Humanoid and fires the initial
-- data packet to the client after load.  Also re-syncs HP on respawn.
--
-- Dependency injection via Init(); wire each player via WirePlayer().

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local PlayerRemotes = require(
	ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Remotes"):WaitForChild("PlayerRemotes")
)

local CharacterService = {}

local playerDataService: any = nil
local statsService: any      = nil
local initialized            = false

-- ── helpers ──────────────────────────────────────────────────────────────

local function buildInitialPayload(data: { [string]: any }): { [string]: any }
	return {
		level           = data.Level,
		exp             = data.Exp,
		gold            = data.Gold,
		selectedClass   = data.SelectedClass,
		selectedRole    = data.SelectedRole,
		stats           = data.Stats,
		currentHealth   = data.CurrentHealth,
		currentResource = data.CurrentResource,
		resourceType    = data.ResourceType,
	}
end

local function applyHumanoidStats(player: Player, data: { [string]: any })
	local character = player.Character
	if not character then return end
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not humanoid then return end

	local stats  = data.Stats
	local maxHp  = (type(stats) == "table" and stats.MaxHealth) or 100
	local currHp = data.CurrentHealth or maxHp

	humanoid.MaxHealth = maxHp
	humanoid.Health    = math.clamp(currHp, 0, maxHp)
end

local function wireCharacter(player: Player)
	player.CharacterAdded:Connect(function(character: Model)
		-- Small yield so data service finishes loading on first spawn
		task.wait(0.15)
		local data = playerDataService.GetData(player)
		if not data then return end

		applyHumanoidStats(player, data)

		local humanoid = character:WaitForChild("Humanoid", 5)
		if not humanoid or not humanoid:IsA("Humanoid") then return end

		-- Mirror Humanoid HP into player data in real-time
		humanoid.HealthChanged:Connect(function(hp: number)
			local d = playerDataService.GetData(player)
			if d then d.CurrentHealth = hp end
		end)

		-- On death restore to 50 % so the player doesn't respawn at 0
		humanoid.Died:Connect(function()
			local d = playerDataService.GetData(player)
			if d then
				local maxHp = (type(d.Stats) == "table" and d.Stats.MaxHealth) or 100
				d.CurrentHealth = math.max(1, math.floor(maxHp * 0.5))
			end
		end)
	end)
end

-- ── public API ────────────────────────────────────────────────────────────

--- Called by Boot after PlayerDataService.LoadPlayer succeeds.
function CharacterService.OnPlayerLoaded(player: Player)
	local data = playerDataService.GetData(player)
	if not data then return end

	local hasClass = type(data.SelectedClass) == "string" and data.SelectedClass ~= ""

	if not hasClass then
		-- No class yet → ask the client to show the class-selector screen.
		PlayerRemotes.GetEvent("NeedsClassSelect"):FireClient(player)
	else
		statsService.Recalculate(player)
		data = playerDataService.GetData(player)  -- refresh after recalc
		PlayerRemotes.GetEvent("SendInitialData"):FireClient(player, buildInitialPayload(data))
		applyHumanoidStats(player, data)
	end
end

--- Called by ServerHandlers after a successful class + role selection round-trip.
function CharacterService.OnClassSelected(player: Player)
	local data = playerDataService.GetData(player)
	if not data then return end

	statsService.Recalculate(player)
	data = playerDataService.GetData(player)

	PlayerRemotes.GetEvent("SendInitialData"):FireClient(player, buildInitialPayload(data))
	applyHumanoidStats(player, data)
end

--- Broadcast updated stats to the client (call after equip / level-up / etc.).
function CharacterService.SyncToClient(player: Player)
	local data = playerDataService.GetData(player)
	if not data then return end
	PlayerRemotes.GetEvent("SyncStats"):FireClient(player, {
		stats           = data.Stats,
		currentHealth   = data.CurrentHealth,
		currentResource = data.CurrentResource,
		level           = data.Level,
		exp             = data.Exp,
		gold            = data.Gold,
	})
end

function CharacterService.Init(newPlayerDataService: any, newStatsService: any)
	if initialized then
		warn("[CharacterService] Init called more than once; ignoring.")
		return
	end
	assert(newPlayerDataService, "[CharacterService] requires PlayerDataService")
	assert(newStatsService,      "[CharacterService] requires StatsService")

	playerDataService = newPlayerDataService
	statsService      = newStatsService
	initialized       = true
	print("[CharacterService] Initialized.")
end

--- Wire up CharacterAdded for a player.
--- Call from Boot right after Init, once per player.
function CharacterService.WirePlayer(player: Player)
	wireCharacter(player)
end

return CharacterService
