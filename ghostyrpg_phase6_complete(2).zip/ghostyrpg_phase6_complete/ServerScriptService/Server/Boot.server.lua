--!strict
--------------------------------------------------------------------------------
-- GhostyRPG | Boot.server.lua
-- ServerScriptService/Server/Boot.server.lua
--
-- Service init order and player profile lifecycle.
--
-- Phase 6 additions:
--   • AbilityRemotes.Ensure()
--   • SpellEffectService.Init(PlayerDataService, StatsService, AbilityRemotes)
--   • AbilityService.Init(PlayerDataService, StatsService, SpellEffectService,
--                          MagicTierService, AbilityRemotes)
--   • AbilityService + SpellEffectService added to ServerHandlers context
--------------------------------------------------------------------------------

local Players             = game:GetService("Players")
local ServerScriptService = game:GetService("ServerScriptService")
local ReplicatedStorage   = game:GetService("ReplicatedStorage")

local Server   = ServerScriptService:WaitForChild("Server")
local Services = Server:WaitForChild("Services")
local Remotes  = ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Remotes")
local Net      = Server:WaitForChild("Net")

--------------------------------------------------------------------------------
-- REQUIRES
--------------------------------------------------------------------------------

-- Core data + stats
local PlayerDataService = require(Services:WaitForChild("PlayerDataService"))
local StatsService      = require(Services:WaitForChild("StatsService"))

-- Combat
local CombatService     = require(Services:WaitForChild("CombatService"))

-- Character / class
local ClassService      = require(Services:WaitForChild("ClassService"))
local CharacterService  = require(Services:WaitForChild("CharacterService"))

-- Progression
local LevelService      = require(Services:WaitForChild("LevelService"))

-- Inventory / loot
local InventoryService  = require(Services:WaitForChild("InventoryService"))
local LootService       = require(Services:WaitForChild("LootService"))
local LootDropService   = require(Services:WaitForChild("LootDropService"))

-- Professions
local ProfessionService = require(Services:WaitForChild("ProfessionService"))

-- Social / multiplayer
local PartyService      = require(Services:WaitForChild("PartyService"))
local ArenaService      = require(Services:WaitForChild("ArenaService"))

-- Quest + dungeon
local QuestService      = require(Services:WaitForChild("QuestService"))
local DungeonService    = require(Services:WaitForChild("DungeonService"))
local QueueService      = require(Services:WaitForChild("QueueService"))

-- Mobs
local MobService        = require(Services:WaitForChild("MobService"))
local MobAIService      = require(Services:WaitForChild("MobAIService"))

-- Phase 5: Overlord systems
local MagicTierService  = require(Services:WaitForChild("MagicTierService"))
local TombBaseService   = require(Services:WaitForChild("TombBaseService"))

-- Phase 6: Ability / spell system
local SpellEffectService = require(Services:WaitForChild("SpellEffectService"))
local AbilityService     = require(Services:WaitForChild("AbilityService"))

-- Remotes
local ClassRemotes      = require(Remotes:WaitForChild("ClassRemotes"))
local InventoryRemotes  = require(Remotes:WaitForChild("InventoryRemotes"))
local DungeonRemotes    = require(Remotes:WaitForChild("DungeonRemotes"))
local QuestRemotes      = require(Remotes:WaitForChild("QuestRemotes"))
local PlayerRemotes     = require(Remotes:WaitForChild("PlayerRemotes"))
local PartyRemotes      = require(Remotes:WaitForChild("PartyRemotes"))
local ArenaRemotes      = require(Remotes:WaitForChild("ArenaRemotes"))
local AbilityRemotes    = require(Remotes:WaitForChild("AbilityRemotes"))  -- Phase 6

-- Net handler
local ServerHandlers    = require(Net:WaitForChild("ServerHandlers"))

--------------------------------------------------------------------------------
-- SERVICE INITIALISATION — order matters
--------------------------------------------------------------------------------

-- 1. Player data must come first; everything else reads from it
PlayerDataService.Init()

-- 2. Stats — depends on PlayerDataService
StatsService.Init(PlayerDataService)

-- 3. Combat — depends on PlayerData + Stats
CombatService.Init(PlayerDataService, StatsService)

-- 4. Class + Character
ClassService.Init(PlayerDataService, StatsService)
CharacterService.Init(PlayerDataService, StatsService)

-- 5. Phase 5: MagicTier early so LevelService / DungeonService can reference it
MagicTierService.Init(PlayerDataService, StatsService)

-- 6. Level — depends on MagicTierService for tier advancement
LevelService.Init(PlayerDataService, StatsService, CharacterService, MagicTierService)

-- 7. Inventory / loot pipeline
InventoryService.Init(PlayerDataService)
LootService.Init(InventoryService)
LootDropService.Init(InventoryService)

-- 8. Professions
ProfessionService.Init(PlayerDataService, InventoryService)

-- 9. Social
PartyService.Init(PlayerDataService)
ArenaService.Init(PlayerDataService, MagicTierService)

-- 10. Quest + Dungeon
QuestService.Init(PlayerDataService, InventoryService, LevelService, MagicTierService)
DungeonService.Init(PlayerDataService, PartyService, QuestService, InventoryService, MagicTierService)
QueueService.Init(PlayerDataService, PartyService, DungeonService)

-- 11. Mob AI
MobService.Init(PlayerDataService, QuestService, InventoryService, LootService)
MobAIService.Init(
	PlayerDataService, QuestService, LootService,
	LevelService, LootDropService, MagicTierService
)

-- 12. Phase 5: Tomb / Overlord base
TombBaseService.Init(PlayerDataService, InventoryService, MagicTierService)

-- 13. Phase 6: Spell + Ability pipeline
--     SpellEffectService must initialise BEFORE AbilityService so the
--     reference to SpellEffectService.Apply is valid when AbilityService wires
--     up the CastAbility remote inside its own Init().
AbilityRemotes.Ensure()
SpellEffectService.Init(PlayerDataService, StatsService, AbilityRemotes)
AbilityService.Init(
	PlayerDataService,
	StatsService,
	SpellEffectService,
	MagicTierService,
	AbilityRemotes
)

--------------------------------------------------------------------------------
-- REMOTES
-- All Ensure() calls before ServerHandlers.Init so clients can WaitForChild.
--------------------------------------------------------------------------------

PlayerRemotes.Ensure()
ClassRemotes.Ensure()
InventoryRemotes.Ensure()
DungeonRemotes.Ensure()
QuestRemotes.Ensure()
PartyRemotes.Ensure()
ArenaRemotes.Ensure()
-- AbilityRemotes already ensured above (before SpellEffectService.Init)

--------------------------------------------------------------------------------
-- SERVER HANDLERS
--------------------------------------------------------------------------------

ServerHandlers.Init({
	PlayerDataService  = PlayerDataService,
	ClassService       = ClassService,
	CharacterService   = CharacterService,
	QueueService       = QueueService,
	DungeonService     = DungeonService,
	CombatService      = CombatService,
	InventoryService   = InventoryService,
	ProfessionService  = ProfessionService,
	QuestService       = QuestService,
	PartyService       = PartyService,
	ArenaService       = ArenaService,
	MagicTierService   = MagicTierService,
	TombBaseService    = TombBaseService,
	-- Phase 6
	AbilityService     = AbilityService,
	SpellEffectService = SpellEffectService,
})

--------------------------------------------------------------------------------
-- PLAYER LIFECYCLE
--------------------------------------------------------------------------------

local function onPlayerAdded(player: Player)
	CharacterService.WirePlayer(player)
	task.spawn(function()
		PlayerDataService.LoadPlayer(player)
		if PlayerDataService.IsLoaded(player) then
			CharacterService.OnPlayerLoaded(player)

			-- Phase 6: send initial ability bar state to the new client
			-- Get player data to determine class/tier
			local data = PlayerDataService.GetData(player)
			if data then
				local className = data.SelectedClass or ""
				local roleName  = data.SelectedRole  or ""
				local level     = data.Level          or 1
				local magicTier = data.MagicTier      or 1

				local AbilityConfig = require(
					ReplicatedStorage:WaitForChild("Shared")
						:WaitForChild("Config")
						:WaitForChild("AbilityConfig")
				)

				local available = AbilityConfig.GetAvailableAbilities(
					className, roleName, level, magicTier
				)
				local ids: { string } = {}
				for _, ab in ipairs(available) do
					table.insert(ids, ab.id)
					if #ids >= 6 then break end
				end

				-- Notify client of initial ability grant
				pcall(function()
					AbilityRemotes.GetEvent("AbilityGranted"):FireClient(player, {
						unlockedSpells = ids,
						magicTier      = magicTier,
					})
				end)
			end
		end
	end)
end

local function onPlayerRemoving(player: Player)
	PlayerDataService.ReleasePlayer(player)
end

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(onPlayerRemoving)

for _, player in ipairs(Players:GetPlayers()) do
	task.spawn(onPlayerAdded, player)
end

game:BindToClose(function()
	for _, player in ipairs(Players:GetPlayers()) do
		PlayerDataService.ReleasePlayer(player)
	end
end)

print("[GhostyRPG] Server boot complete — Phase 6 active.")
